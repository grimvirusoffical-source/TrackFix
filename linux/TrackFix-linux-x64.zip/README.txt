TrackFix

Open Guide/index.html. That folder has Practice, Apps, Install, Updates, and Support.
Help: https://discord.gg/8ESRPHcu2

Windows: open TrackFix.exe. If SmartScreen appears, choose More info, then Run anyway.
The tray icon has Guide.

Mac: Control-click TrackFix, choose Open, then Open again.
Allow it under Privacy & Security, Accessibility. Ctrl+Shift+Q quits.

Linux: chmod +x TrackFix && ./TrackFix
Type y if it asks to read the trackpad. Press h for the guide. Press q to quit.
