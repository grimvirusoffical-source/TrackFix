TrackFix 2.2
Double-click TrackFix.exe.
Windows asks for permission. Choose Yes.
Or right-click TrackFix.exe and choose Run as administrator.
Do not open this file in an editor.
Guide pages are in the Guide folder.
Help: https://github.com/grimvirusoffical-source/TrackFix
