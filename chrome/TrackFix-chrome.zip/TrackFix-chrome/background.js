chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== "zoom" || !sender.tab || typeof msg.delta !== "number") return;
  const id = sender.tab.id;
  chrome.tabs
    .getZoom(id)
    .then((current) => {
      const next = Math.min(5, Math.max(0.25, current * Math.pow(1.0015, msg.delta)));
      return chrome.tabs.setZoom(id, next);
    })
    .catch(() => {});
});
