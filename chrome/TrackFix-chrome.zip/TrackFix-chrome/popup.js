const DEFAULTS = {
  scrollCode: "ControlRight",
  zoomCode: "ShiftRight",
  navCode: "F8",
  sensitivity: 24,
  invert: false,
};

const NAMES = {
  ControlRight: "Right Ctrl",
  ControlLeft: "Left Ctrl",
  ShiftRight: "Right Shift",
  ShiftLeft: "Left Shift",
  AltRight: "Right Alt",
  AltLeft: "Left Alt",
  Backquote: "`",
  F8: "F8",
};

let settings = { ...DEFAULTS };
let waiting = null;

function label(code) {
  if (NAMES[code]) return NAMES[code];
  if (code.startsWith("Key")) return code.slice(3);
  if (code.startsWith("Digit")) return code.slice(5);
  return code;
}

function paint() {
  for (const key of ["scrollCode", "zoomCode", "navCode"]) {
    const button = document.querySelector(`[data-key="${key}"]`);
    button.textContent = waiting === key ? "Press a key" : label(settings[key]);
    button.classList.toggle("wait", waiting === key);
  }
  document.getElementById("sens").value = String(settings.sensitivity);
  document.getElementById("invert").checked = Boolean(settings.invert);
}

function save(next) {
  settings = next;
  chrome.storage.local.set(settings);
  paint();
}

document.querySelectorAll("[data-page]").forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    const page = link.getAttribute("data-page");
    chrome.tabs.create({ url: chrome.runtime.getURL("guide/" + page) });
  });
});

document.querySelectorAll("[data-key]").forEach((button) => {
  button.addEventListener("click", () => {
    waiting = button.getAttribute("data-key");
    paint();
  });
});

document.addEventListener("keydown", (event) => {
  if (!waiting) return;
  event.preventDefault();
  if (event.code === "Escape") {
    waiting = null;
    paint();
    return;
  }
  save({ ...settings, [waiting]: event.code });
  waiting = null;
});

document.getElementById("sens").addEventListener("input", (event) => {
  save({ ...settings, sensitivity: Number(event.target.value) });
});

document.getElementById("invert").addEventListener("change", (event) => {
  save({ ...settings, invert: event.target.checked });
});

document.getElementById("preset").addEventListener("click", () => {
  save({
    ...settings,
    scrollCode: "AltLeft",
    zoomCode: "AltRight",
    navCode: "Backquote",
  });
  document.getElementById("hint").textContent =
    "Alt scrolls, the other Alt zooms, the key under Esc pans. Click Change if a key is missing.";
});

chrome.storage.local.get(DEFAULTS, (saved) => {
  settings = { ...DEFAULTS, ...saved };
  paint();
});
