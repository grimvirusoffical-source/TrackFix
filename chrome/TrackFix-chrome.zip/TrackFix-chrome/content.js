const DEFAULTS = {
  scrollCode: "ControlRight",
  zoomCode: "ShiftRight",
  navCode: "F8",
  sensitivity: 24,
  invert: false,
};

let settings = { ...DEFAULTS };
let mode = null;
let acc = 0;
let fdy = 0;
let zoomQueue = 0;
let zoomTimer = 0;

function loadSettings() {
  if (!chrome.storage || !chrome.storage.local) return;
  chrome.storage.local.get(DEFAULTS, (saved) => {
    settings = { ...DEFAULTS, ...saved };
  });
}

loadSettings();
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener(loadSettings);
}

function fingerUp(dy) {
  const sens = Math.max(1, settings.sensitivity | 0);
  let d = dy;
  if (d > 400) d = 400;
  if (d < -400) d = -400;
  fdy = Math.trunc((fdy * 2 + d * 4) / 6);
  d = fdy;
  if (!d) return 0;
  acc += d * 120;
  const emit = Math.trunc(acc / sens);
  acc -= emit * sens;
  return -emit;
}

function codeMode(code) {
  if (code === settings.scrollCode) return "scroll";
  if (code === settings.zoomCode) return "zoom";
  if (code === settings.navCode) return "nav";
  return null;
}

function scrollable(x, y) {
  let el = document.elementFromPoint(x, y);
  while (el) {
    const style = getComputedStyle(el);
    const yScroll = style.overflowY === "auto" || style.overflowY === "scroll" || style.overflowY === "overlay";
    const xScroll = style.overflowX === "auto" || style.overflowX === "scroll" || style.overflowX === "overlay";
    if ((yScroll && el.scrollHeight > el.clientHeight + 2) || (xScroll && el.scrollWidth > el.clientWidth + 2)) {
      return el;
    }
    el = el.parentElement;
  }
  return document.scrollingElement || document.documentElement;
}

function flushZoom() {
  const delta = zoomQueue;
  zoomQueue = 0;
  zoomTimer = 0;
  if (!delta || !chrome.runtime) return;
  chrome.runtime.sendMessage({ type: "zoom", delta }).catch(() => {});
}

document.addEventListener(
  "keydown",
  (event) => {
    if (event.repeat) return;
    const next = codeMode(event.code);
    if (!next) return;
    mode = next;
    acc = 0;
    fdy = 0;
    event.preventDefault();
    event.stopPropagation();
    const root = document.documentElement;
    if (root && root.requestPointerLock && !document.pointerLockElement) {
      root.requestPointerLock();
    }
  },
  true,
);

document.addEventListener(
  "keyup",
  (event) => {
    if (codeMode(event.code) !== mode) return;
    mode = null;
    if (document.pointerLockElement) document.exitPointerLock();
    event.preventDefault();
  },
  true,
);

document.addEventListener(
  "pointermove",
  (event) => {
    if (!mode) return;
    const dy = event.movementY || 0;
    const dx = event.movementX || 0;
    if (!dx && !dy) return;
    event.preventDefault();
    const up = fingerUp(dy);
    const node = scrollable(event.clientX, event.clientY);
    if (mode === "scroll") {
      const wheel = settings.invert ? -up : up;
      node.scrollTop -= wheel * 0.45;
      return;
    }
    if (mode === "zoom") {
      zoomQueue += -up;
      if (!zoomTimer) zoomTimer = setTimeout(flushZoom, 40);
      return;
    }
    node.scrollLeft += dx;
    node.scrollTop += dy;
  },
  true,
);
